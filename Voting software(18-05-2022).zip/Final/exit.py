import tkinter as tk
import sqlite3 as sq3
from tkinter import messagebox

def exit():
    root.destroy()
